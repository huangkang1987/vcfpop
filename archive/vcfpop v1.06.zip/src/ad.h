/* Allelic Depth Analysis Functions, TEST, DO NOT USE */

#pragma once
#include "vcfpop.h"

#pragma pack(push, 1)

#pragma pack(pop)
