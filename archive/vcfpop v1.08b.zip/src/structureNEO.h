/* NEO Bayesian clustering functions */

#pragma once
#include "vcfpop.h"