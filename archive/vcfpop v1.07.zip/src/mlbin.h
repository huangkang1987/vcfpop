/* Resources for Huang 2015 Maximum-likelihood relatedness estimator */

#pragma once
#include "vcfpop.h"

extern byte mlbin_data[155232];