/* AVX512 Bayesian clustering functions */

#pragma once
#include "vcfpop.h"