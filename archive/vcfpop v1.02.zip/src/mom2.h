/* Method-of-moment estimation of relatedness coefficient for polyploids */

#pragma once
#include "vcfpop.h"

void MOMRelatednessAssign8(int refmode, double *e, double *f, int *xx);